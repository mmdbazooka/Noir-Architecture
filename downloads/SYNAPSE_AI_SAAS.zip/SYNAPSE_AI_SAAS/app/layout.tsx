import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import "./globals.css";
import "./synapse.css";
const inter = localFont({
  src: "../node_modules/@fontsource-variable/inter/files/inter-latin-wght-normal.woff2",
  variable: "--font-body",
  display: "swap",
});
const display = localFont({
  src: "../node_modules/@fontsource-variable/space-grotesk/files/space-grotesk-latin-wght-normal.woff2",
  variable: "--font-display",
  display: "swap",
});
export const metadata: Metadata = {
  title: "Synapse \u2014 A little less busy. A lot more brilliant.",
  description:
    "Your ideas, amplified. Discover an intelligent workspace for meaningful work.",
  openGraph: {
    title: "Synapse \u2014 A little less busy. A lot more brilliant.",
    description:
      "Your ideas, amplified. Discover an intelligent workspace for meaningful work.",
    type: "website",
  },
  robots: { index: true, follow: true },
};
export const viewport: Viewport = { themeColor: "#090b10" };
export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body className={`${inter.variable} ${display.variable}`}>
        <a className="skip-link" href="#main">
          Skip to content
        </a>
        {children}
      </body>
    </html>
  );
}
