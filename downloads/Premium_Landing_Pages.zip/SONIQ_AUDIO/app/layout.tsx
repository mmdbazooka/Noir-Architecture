import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import "./globals.css";
import "./soniq.css";
const inter = localFont({
  src: "../node_modules/@fontsource-variable/inter/files/inter-latin-wght-normal.woff2",
  variable: "--font-body",
  display: "swap",
});
const display = localFont({
  src: "../node_modules/@fontsource-variable/space-grotesk/files/space-grotesk-latin-wght-normal.woff2",
  variable: "--font-display",
  display: "swap",
});
export const metadata: Metadata = {
  title: "SONIQ H1 \u2014 Hear every detail",
  description:
    "Less noise. More feeling. Discover the H1 wireless studio headphone concept.",
  openGraph: {
    title: "SONIQ H1 \u2014 Hear every detail",
    description:
      "Less noise. More feeling. Discover the H1 wireless studio headphone concept.",
    type: "website",
  },
  robots: { index: true, follow: true },
};
export const viewport: Viewport = { themeColor: "#090b10" };
export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body className={`${inter.variable} ${display.variable}`}>
        <a className="skip-link" href="#main">
          Skip to content
        </a>
        {children}
      </body>
    </html>
  );
}
