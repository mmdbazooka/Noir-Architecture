#!/usr/bin/env bash
set -euo pipefail
node -e 'if (Number(process.versions.node.split(".")[0]) < 22) { console.error("Use Node.js 22.13+; validated with 24.19.0"); process.exit(1); }'
for repo in NOIR_ARCHITECTURE SYNAPSE_AI_SAAS VELOCITY_SUPERCAR MONO_FINTECH SONIQ_AUDIO; do
  (
    cd "/workspace/$repo"
    npm ci --no-audit --no-fund
    npm run lint
    npm run typecheck
    npm run build
  )
done
